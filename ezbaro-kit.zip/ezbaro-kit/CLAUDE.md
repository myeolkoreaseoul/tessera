# 이지바로 상시점검 자동화

## 역할
통합이지바로(ezbaro.kr)에서 국가R&D 과제의 집행내역을 상시점검한다.
집행건별로 첨부 증빙을 OCR로 읽고, 혁신법 매뉴얼 기준으로 판정하여,
점검의견을 입력하고 보완요청까지 자동 수행한다.

## 환경
- Node.js + Playwright
- Chrome 디버그 모드: `--remote-debugging-port=9444 --user-data-dir=C:\chrome-debug-profile`
- Playwright: `chromium.connectOverCDP('http://localhost:9444')`
- 반드시 `--user-data-dir` 포함해야 디버그 포트 열림

## 판정 방식
- data.json의 OCR 텍스트를 직접 읽고 종합 판단
- `guidelines/innovation-act.md`의 혁신법 기준 참조
- **키워드 매칭 금지** — 문서의 맥락을 종합적으로 판단할 것
- "품의서" = 내부결재문서, "지출결의서" = 지급증빙
- 보수적 판단: 확실한 경우만 점검완료, 나머지 보완요청
- 전자세금계산서는 시스템 자동 연동 → 별도 첨부 불요

## 파이프라인
```
Phase 0: Chrome 디버그 모드로 이지바로 로그인 + 점검 페이지 이동
Phase 1: 그리드에서 집행내역 전체 추출
Phase 2: 각 행의 첨부파일 다운로드
Phase 3: 첨부파일 OCR (PDF, HWP, Excel, 이미지)
Phase 4: data.json 저장
Phase 5: AI가 data.json 읽고 guidelines/ 참조하여 판정 → results.json
Phase 6: results.json 기반으로 점검의견 자동 입력
```

## 핵심 주의사항
- 그리드 행 선택은 반드시 그리드 API 사용 (DOM 클릭 비추)
- 상세→목록 복귀 시 필터/설정 초기화됨 → 매번 재설정
- OCR 텍스트 상한 12,000자
- 상세 진입 전 페이지 상태 저장, 복귀 후 복원
- OCR 한국어 공백 문제: "회 의 록" → fuzzy matching 필요

## results.json 형식
```json
{
  "rowNum": 1,
  "type": "인건비",
  "subType": "내부인건비(비영리)",
  "purpose": "2025년 1월 인건비",
  "amount": 3500000,
  "vendor": "OO대학교",
  "status": "보완요청",
  "issues": ["참여연구자현황표 미첨부", "계좌이체증명 미첨부"],
  "ok": ["급여명세서 ✓"],
  "comment": "1. 참여연구자현황표(연구자명, 참여기간, 인건비계상률 등) 2. 계좌이체증명 등 보완 바랍니다."
}
```

## 첫 번째 작업: 이지바로 DOM 분석
Chrome 디버그 모드로 이지바로 상시점검 페이지에 접속한 뒤:
1. 점검 대상 과제 목록 URL/구조 파악
2. 그리드 라이브러리 파악 (IBSheet? ag-Grid? 자체?)
3. 집행내역 그리드 셀렉터/API 파악
4. 첨부파일 다운로드 방법
5. 점검의견 입력 필드 + 보완요청 버튼 셀렉터
→ 이 분석 결과로 navigate/extract/review 스크립트 작성
